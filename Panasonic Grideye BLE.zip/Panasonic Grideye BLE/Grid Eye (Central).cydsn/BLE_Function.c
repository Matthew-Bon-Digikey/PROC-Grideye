/* 

 This files contains the functions which handle the various ble events which occur as a result of connection events or user input

Written by M. Bon for Digikey Electronics
October 2016

*/
#include "main.h" 
#include "BLE_Function.h" 

/*Flags */ 
uint8 IndicationEnabled       = False;
uint8 Peripheral_device_found = False;

/*locals*/ 
uint8 i                       = 0;  //generic counter
uint8 j                       = 0;  //generic counter 
uint8 GrideyeData[130]       = {0}; //Stores data packet 
uint8 ThermistorData[2]      = {0}; 
char  Outputstring[30]       = {0}; //Used to print to terminal 


/*Globals */ 
uint8 GattState = 0; 


/*Functions */ 

void HandleScanningState()
{
  CYBLE_API_RESULT_T      cyble_api_result;
    
  
    
  switch(cyBle_state) 
    { 
        case CYBLE_STATE_SCANNING:
        {
            if (Peripheral_device_found == True)
                {
                    CyBle_GapcStopScan();
                    
                    
                }
                
            break; 
            
        }
        
        case CYBLE_STATE_CONNECTED:
        {
            Connected = 1; 
            
            break; 
        } 
        
        case CYBLE_STATE_DISCONNECTED:
        {
            if (Peripheral_device_found == True) 
            { 
                cyble_api_result = CyBle_GapcConnectDevice(&GridEyeAddr); //Connect to Peripheral 
                //Connected = 1; 
                
			    if(CYBLE_ERROR_OK != cyble_api_result)
			    {
				   Peripheral_device_found = False;
                   CyBle_GapcStartScan(CYBLE_SCANNING_FAST);
                   Connected = 0; 
			    }
            } 
            
            break; 
        }
        
        /*The following three states are not used in this particular application, but are enumerated for benefit of user looking to 
          repurpose this program for their own uses*/ 
        case CYBLE_STATE_INITIALIZING: 
        {    
            break;    
        }
        
        case CYBLE_STATE_STOPPED: 
        { 
            break; 
        } 
        
        case CYBLE_STATE_CONNECTING:
        {
          break;   
        }     
        
    }
    
}

void BLECallBack(uint32 event, void *eventParam)
{
    
    CYBLE_GAPC_ADV_REPORT_T		            *advReport;
    
    CYBLE_GATTC_READ_RSP_PARAM_T            *valueReport; 
    
    CYBLE_GATTC_HANDLE_VALUE_NTF_PARAM_T    *notification; 
    
    
    
    
        switch(event) 
        { 
            
        case CYBLE_EVT_STACK_ON: 
            { 
                CyBle_GapcStartScan(CYBLE_SCANNING_FAST); 
                break; 
            } 
            
        case CYBLE_EVT_GAPC_SCAN_PROGRESS_RESULT:
            {
                 advReport = (CYBLE_GAPC_ADV_REPORT_T *) eventParam;
                /* check if report has the Grid Eye Command Service enabled.  */
                    if( (advReport->eventType == CYBLE_GAPC_SCAN_RSP) \
                    && (advReport->data[2] == 'G')  && (advReport->data[3] == 'r')  \
                    && (advReport->data[4] == 'i')  && (advReport->data[5] == 'd') && (advReport->data[7] == 'E') \
                    && (advReport->data[8] == 'y') && (advReport->data[9] == 'e'))
                        {
                            Peripheral_device_found = True;
                            memcpy(GridEyeAddr.bdAddr, advReport->peerBdAddr, sizeof(GridEyeAddr.bdAddr));
                            GridEyeAddr.type = advReport->peerAddrType;
                            CyBle_GapcStopScan(); 
                          
                        }
                break; 
            }
        
        case CYBLE_EVT_GAP_DEVICE_CONNECTED: 
            { 
                 
                connHandle = *(CYBLE_CONN_HANDLE_T *)eventParam;
                CyBle_GattcExchangeMtuReq(connHandle, mtuSize);
                Pin_1_Write(1); 
                
                break; 
            } 
            
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            {
               Connected = 0;
               IndicationEnabled = False;
               MTU_Exchanged = False; 
               Pin_1_Write(0); 
                
               break;
                
            }
        
        case CYBLE_EVT_GATTC_XCHNG_MTU_RSP: 
            {
                CYBLE_GATT_XCHG_MTU_PARAM_T        mtuExchgParam; 
            
                mtuExchgParam = *(CYBLE_GATT_XCHG_MTU_PARAM_T*)eventParam;
                
                mtuSize = mtuExchgParam.mtu; 
            
                MTU_Exchanged = True; 
             
                break; 
            }
            
        case CYBLE_EVT_GATTC_ERROR_RSP: 
            {
                UART_UartPutString("Gatt Central error"); 
            
                break;
                
            }
            
        case CYBLE_EVT_GATTC_READ_RSP: 
            {
                
                valueReport = (CYBLE_GATTC_READ_RSP_PARAM_T*) eventParam; 
                value = *valueReport->value.val; 
                
                
                if(command == 'a' || command == 'A') 
                { 
                    
                 sprintf(Outputstring,"Thermistor Reading: %d \r\n",value);
                 UART_UartPutString(Outputstring); 
                 UART_SCB_IRQ_Enable();
                
                    
                } 
                
                else if (command == 'b' || command == 'B')
                {
                   
                 sprintf(Outputstring,"Pixel Reading: %d \r\n",value); 
                 UART_UartPutString(Outputstring);
                 UART_SCB_IRQ_Enable();
                }
                
                else 
                {
                  //Something odd happened
                }
             
                 
                break; 
            }
        
        case CYBLE_EVT_GATTC_HANDLE_VALUE_NTF:
            {
                
           
             notification = (CYBLE_GATTC_HANDLE_VALUE_NTF_PARAM_T*) eventParam;
            
            if (notification->handleValPair.attrHandle == GridEyeDataCharHandle)
            {
                for(i=0;i<GridEyePacket.handleValPair.value.len;i++)
                {
			        GrideyeData[i] = notification->handleValPair.value.val[i]; 
                   
                }
                 
                
                for(i =0; i<8; i++)
                {
                    for(j = 0; j<16; j++)
                    {
                      sprintf(Outputstring," %d ",GrideyeData[(j+i*16)]);
                      UART_UartPutString(Outputstring);
                    }
                    UART_UartPutString("\r\n"); 
                    
                }
                /*print Thermistor bytes*/
                sprintf(Outputstring," %d ",GrideyeData[128]);
                UART_UartPutString(Outputstring);
                
                sprintf(Outputstring," %d ",GrideyeData[129]);
                UART_UartPutString(Outputstring);
                
                                
                UART_UartPutString("\r\n");
                UART_UartPutString("\r\n");
                 
            
            }
                   
                break; 
            }

        default:
            
            {
                break;
                
            }
                              
        } 
        
}



/* [] END OF FILE */
