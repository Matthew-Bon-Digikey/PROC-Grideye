/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/



/*Globals*/ 

/* Service and Charactertics UUID's */ 

#ifndef  BLEFunction_H
#define  BLEFunction_H 
#include <project.h> 

typedef enum
{
   GattScan_Start                   = 0,
   Command_Service_Found            = 1, 
   Command_Char_Found               = 2, 
   ThermistorData_Service_Found     = 3, 
   ThermistorData_Char_Found        = 4, 
   Pixel_Service_Found              = 5, 
   Pixel_Char_Found                 = 6, 
   GridEyeData_Service_Found        = 7, 
   Thermistor_Char_Found            = 8, 
   GridEyeData_Char_Found           = 9, 
   MTU_Exchange                     = 10, 
   All_Handles_Found                = 11, 

} Gatt_Condition; 

#endif

/* [] END OF FILE */
