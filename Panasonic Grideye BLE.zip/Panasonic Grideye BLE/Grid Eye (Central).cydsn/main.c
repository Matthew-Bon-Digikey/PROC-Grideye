  /* 
The following is a simple demo program to connect to and control the PROC Grideye Demo board 

Written by M. Bon for Digikey Electronics
October 2016
 
*/
#include "main.h"


/*Declarations */ 

/*Globals */ 
volatile uint8 command  = 0;     //Stores command paratmeter 
uint8 pixel_number      = 0;     //Stores pixel number sent to BLE Gatt server
uint8 pixel             = 0;     //Stores pixel value sent by the user over the terminal 
uint8 Connected         = False; //Stores connection state 
uint8 value             = 0;     //Stores Read responses from BLE  Gatt server 
uint8 MTU_Exchanged     = False; //Stores state of MTU exchange
uint8 int_src           = 0;     // Stores interrupt source 

/*Locals*/ 
uint8 temp_command                         = 0;     //Used to catch the carriage return 
uint8 GridEyeCommand                       = 0x00;  //Stores user's command 
uint8 PixelNumberCommand                   = 0x00;  
uint8 EnableNotification                   = 0x01; 
uint8 DisableNotification                  = 0x00; 
uint8 stream_start                         = True; 

volatile uint16 mtuSize = CYBLE_GATT_MTU;   //MTU size to be used by Client and Server after MTU exchange 
const    uint8 enableNotificationParam[2] = {0x01, 0x00}; 


/*Function prototypes */

void handle_uart(); // ISR to read in commands from the terminal


/*Service and Characteristic handles*/     
uint16 GridEyeCommandsCharHandle           = 0x00E; 
uint16 GridEyeDataCharHandle               = 0x0012; 
uint16 GridEyeThermistorCharHandle         = 0x0017;  
uint16 GridEyePixelDataCharHandle          = 0x01B; 
uint16 GridEyePixelDataNumberCharHandle    = 0x01E; 
uint16 GridEyeClientDescriptorHandle       = 0x014;
uint16 ThermistorDataDescriptorHandle      = 0x018;


/*Structures*/ 
CYBLE_GATTC_WRITE_REQ_T      enableNotificationReqParam;

CYBLE_GATTC_WRITE_CMD_REQ_T  PixelNumberParam; 

CYBLE_GATTC_READ_REQ_T       ReadThermistorDataParam  = { 0x0017u };

CYBLE_GATTC_READ_REQ_T       ReadPixelDataParam       = { 0x001Bu };
                                                            
CYBLE_GATTC_READ_REQ_T       ReadGridEyeDataParam     = { 0x0012u }; 


                                                          
int main()
{
    /*Start UART, Enable Interrupts, populate BLE strutures and start BLE stack*/ 
    UART_Start(); 
    CyGlobalIntEnable; /* Enable global interrupts. */ 
    Populate_Structures();   
    UART_SetCustomInterruptHandler(handle_uart);
    CyBle_Start(BLECallBack);
       
    /*Loop forever*/ 
    while(1)
    {
   
        while(Connected == 0) //While unconnected process ble events and handle connection events 
        { 
          CyBle_ProcessEvents();
          HandleScanningState(); 
       
        }


        CyDelay(100); 
        HandleScanningState(); 
        CyBle_ProcessEvents();  
        
        UART_UartPutString("Peripheral Found and Connected!\r\n"); 
        UART_UartPutString("Welcome to the PROC Grid Eye Demo program! Enter the letter beside the command to execute it.\r\n");
        UART_UartPutString("The commands are as follows \r\n"); 
        UART_UartPutString("A: Get thermistor data \r\n"); 
        UART_UartPutString("B: Get data from a single pixel \r\n"); 
        UART_UartPutString("C: Start streaming data,(Thermistor + 64 pixels) \r\n"); 
        UART_UartPutString("D: Stop streaming data \r\n");
        UART_UartPutString("Enter Command \r\n");
        
        
            
        
         while(Connected == 1) 
        {
           
           while (MTU_Exchanged == False) //Exchange MTU if it hasn't already been exchanged 
            {
             CyBle_GattcExchangeMtuReq(cyBle_connHandle, mtuSize);
             HandleScanningState();
             CyBle_ProcessEvents(); 
            }
            
            HandleScanningState(); 
            CyBle_ProcessEvents(); 
            UART_SCB_IRQ_Enable();
            
            command = 0; 
            
            pixel_number = 0; //reset pixel variable 
            
            
            while ( (command == 0 || command == 0xFF || command == 0x0D) && Connected == 1) //Process ble events until the user enters a command
                {
                    CyBle_ProcessEvents();
                    
                }
                
            if (Connected == 1) 
            {
                Parse_Command(command); //execute user's input 
            }
                     
        
        }
    }
}


void Parse_Command(uint8 command) 
{ 
  
   if (command == 'a' || command == 'A' ) //Grab thermistor value and print it to the screen. 
        { 
           GridEyeCommand = 0x0A; 
           GridEyeCommandParam.value.val = &GridEyeCommand; 
           GridEyeCommandParam.attrHandle = GridEyeCommandsCharHandle; 
           CyBle_GattcWriteWithoutResponse(cyBle_connHandle, &GridEyeCommandParam); 

           CyBle_ProcessEvents();
        
           CyDelay(10); 
           CyBle_GattcReadCharacteristicValue(cyBle_connHandle, ReadThermistorDataParam);
           CyDelay(100); 
           CyBle_ProcessEvents();
      
           UART_UartPutString("Enter Command \r\n");
           GridEyeCommand = 0; 
        }
        
   else if (command == 'b' || command == 'B') //Grab the value of a specific pixel 
        {
               
            pixel_number = 0; 
            UART_UartPutString("Enter Pixel Number \r\n");     
     
        do
        { 
            while(pixel == 0 || pixel == 0xFF || pixel == 0x0D)
            {
                
            pixel = UART_UartGetChar(); 
            
            if ( pixel > 0x0D && pixel < 0xFF) 
            { 
              Char_to_Pixel_FirstDigit(pixel); 
            }
            
            }
            
            pixel = 0; 
            
            pixel = UART_UartGetChar();
            
            while(pixel == 0 || pixel == 0xFF || pixel == 0x0D)
            {
                
            pixel = UART_UartGetChar(); 
            
            if ( pixel > 0x0D && pixel < 0xFF) 
            { 
              Char_to_Pixel_SecondDigit(pixel); 
            }
            
            }
            
        } while(pixel_number == 0 || pixel_number == 0xFF || pixel_number == 0x0D );  
            
        
            if(pixel_number > 64 && pixel_number !=0xFF) 
            { 
                UART_UartPutString("Invalid Number \r\n"); 
                UART_UartPutString("Enter Command \r\n"); 
                pixel_number = 0; 
            }
            
            else if ( pixel_number != 0) 
            {
            
            PixelNumberCommand = pixel_number; 
            PixelNumberParam.value.val = &PixelNumberCommand; 
            PixelNumberParam.attrHandle = GridEyePixelDataNumberCharHandle; 
            CyBle_GattcWriteWithoutResponse(cyBle_connHandle, &PixelNumberParam); 
            CyBle_ProcessEvents();
            CyDelay(10); 
            
            GridEyeCommand = 0x0B; 
            GridEyeCommandParam.value.val = &GridEyeCommand; 
            GridEyeCommandParam.attrHandle = GridEyeCommandsCharHandle; 
            CyBle_GattcWriteWithoutResponse(cyBle_connHandle, &GridEyeCommandParam); 
            CyBle_ProcessEvents();
            CyDelay(10); 
            
            CyBle_GattcReadCharacteristicValue(cyBle_connHandle, ReadPixelDataParam);
            CyDelay(100); 
            CyBle_ProcessEvents();
            
            UART_UartPutString("Enter Command \r\n");
            
            }
        
        pixel = 0; 
        }
        
   else if (command == 'c' || command == 'C') //Start streaming full packets of data 
        { 
           
           if (stream_start == True)
            {
               /*Enable GridEye Data notification */ 
               enableNotificationReqParam.attrHandle = GridEyeClientDescriptorHandle;   
               enableNotificationReqParam.value.val = &EnableNotification; 
    	       CyBle_GattcWriteCharacteristicDescriptors(cyBle_connHandle, &enableNotificationReqParam);
               
               /*Write GridEye Command*/ 
               GridEyeCommand = 0x0C; 
               GridEyeCommandParam.value.val = &GridEyeCommand; 
               GridEyeCommandParam.attrHandle = GridEyeCommandsCharHandle; 
               CyBle_GattcWriteWithoutResponse(cyBle_connHandle, &GridEyeCommandParam); 
               CyBle_ProcessEvents();
               CyDelay(100); 
                
               //  Get packet & print packet  
               UART_UartPutString("Data Stream Start \r\n"); 
            
               CyBle_ProcessEvents(); 
               UART_SCB_IRQ_Enable();
                 
                
               UART_UartPutString("Enter Command \r\n");
               stream_start = False; 
            }
            
        
        }
        
   else if (command == 'd' || command == 'D') 
        { 
            
           /*Disable GridEye Data notification */ 
           enableNotificationReqParam.attrHandle = GridEyeClientDescriptorHandle;   
           enableNotificationReqParam.value.val = &DisableNotification; 
	       CyBle_GattcWriteCharacteristicDescriptors(cyBle_connHandle, &enableNotificationReqParam);
           
           /*Write GridEye Command*/ 
           GridEyeCommand = 0x0D; 
           GridEyeCommandParam.value.val = &GridEyeCommand; 
           GridEyeCommandParam.attrHandle = GridEyeCommandsCharHandle; 
           CyBle_GattcWriteWithoutResponse(cyBle_connHandle, &GridEyeCommandParam); 
           CyBle_ProcessEvents();
           CyDelay(100); 
           CyBle_ProcessEvents();
        
            //Stop data 
            CyDelay(2000); //wait for the last packet to appear, might take up to 2 seconds 
            CyBle_ProcessEvents();
            UART_UartPutString("Data Stream Stopped \r\n"); 
            UART_UartPutString("Enter Command \r\n");
            UART_SCB_IRQ_Enable();
            stream_start = True; 
        }
       
   else 
        { 
            // Insult the user 
            UART_UartPutString("Invalid Command \r\n"); 
            UART_UartPutString("Enter Command \r\n");
            UART_SCB_IRQ_Enable();
        }
            
    pixel_number = 0;//reset pixel number  
    value = 0; 
        
}

void Char_to_Pixel_FirstDigit(uint8 pixel) //Converts terminal input to first digit of the pixel number 
{
    switch (pixel)
    {
       case '0': 
        { 
            pixel_number = pixel_number + 0; 
           break; 
        }
       case '1': 
        { 
            pixel_number = pixel_number + 10; 
            break;
        }
       case '2': 
        { 
            pixel_number = pixel_number + 20; 
            break;
        }
       case '3': 
        { 
            pixel_number = pixel_number + 30; 
            break;
        }
       case '4': 
        { 
            pixel_number = pixel_number + 40;
            break;
        }
       case '5': 
        { 
            pixel_number = pixel_number + 50; 
            break;

        }
       case '6': 
        { 
            pixel_number = pixel_number + 60; 
            break;
        }
       case '7': 
        { 
            pixel_number = pixel_number + 70; 
            break;
        }
       case '8': 
        { 
            pixel_number = pixel_number + 80; 
            break;
        }
       case '9': 
        { 
            pixel_number = pixel_number + 90; 
            break;
        }
    }
    
}

void Char_to_Pixel_SecondDigit(uint8 pixel) //Converts terminal input to second digit of the pixel number 
{
    switch (pixel)
    {
       case '0': 
        { 
            pixel_number = pixel_number + 0; 
            break;
        }
       case '1': 
        { 
            pixel_number = pixel_number + 1; 
            break;
        }
       case '2': 
        { 
            pixel_number = pixel_number + 2; 
            break;
        }
       case '3': 
        { 
            pixel_number = pixel_number + 3;
            break;
        }
       case '4': 
        { 
            pixel_number = pixel_number + 4; 
            break;
        }
       case '5': 
        { 
            pixel_number = pixel_number + 5; 
            break;

        }
       case '6': 
        { 
            pixel_number = pixel_number + 6; 
            break;
        }
       case '7': 
        { 
            pixel_number = pixel_number + 7; 
            break;
        }
       case '8': 
        { 
            pixel_number = pixel_number + 8; 
            break;
        }
       case '9': 
        { 
            pixel_number = pixel_number + 9; 
            break;
        }
    }
    
}

void Populate_Structures()
{
    //Populate Command Structure. 
    GridEyeCommandParam.attrHandle = 0x00E; 
    GridEyeCommandParam.value.len = 1; 
    GridEyeCommandParam.value.val = &GridEyeCommand; 
    
    //Populate Pixel Number Command Structure 
    PixelNumberParam.attrHandle = 0x01E; 
    PixelNumberParam.value.len = 1; 
    PixelNumberParam.value.val = &PixelNumberCommand; 
    
    //Populate the Grid Eye Data Notification Structure 
    GridEyePacket.handleValPair.attrHandle = GridEyeCommandsCharHandle; 
    GridEyePacket.handleValPair.value.len = 130; 
    GridEyePacket.handleValPair.value.actualLen = 130;
    
}

void handle_uart() //Reads in commands from the user 
{       
   
  
    /*Read in command*/ 
     temp_command = UART_UartGetChar();
    
    if (temp_command !=0x0D) //Catch carriage return
    {
       command = temp_command; 
        
    }
        
     int_src = UART_GetRxInterruptSource();
     UART_ClearRxInterruptSource(int_src);
     UART_SCB_IRQ_Disable();
       
}



/* [] END OF FILE */
