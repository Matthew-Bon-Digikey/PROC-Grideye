/*
Written by M. Bon for Digikey Electronics
October 2016
*/

#include "BLE_Function.h"
#include <stdio.h>
#include <project.h>
    
/*Declarations*/ 
#define True    (1) 
#define False   (0) 


#ifndef Main_H
#define Main_H
    
CYBLE_CONN_HANDLE_T			connHandle;
    
/*Globals */     
        
extern uint8 Peripheral_device_found;
extern uint8 Connected;
extern uint8 GattState;  
volatile uint8 command; 
extern uint8 value; 
extern uint8 GrideyeData[130]; 
volatile uint16 mtuSize; 
extern uint8 MTU_Exchanged; 
    
/*Service and Characteristic handles*/     
extern uint16 GridEyeCommandsCharHandle;           
extern uint16 GridEyeDataCharHandle; 
extern uint16 GridEyeThermistorCharHandle;  
extern uint16 GridEyePixelDataCharHandle; 
extern uint16 GridEyePixelDataNumberCharHandle; 
extern uint16 GridEyeClientDescriptorHandle;
extern uint16 ThermistorDataDescriptorHandle;
extern uint8  GridEyeCommand;
CYBLE_GATTC_WRITE_CMD_REQ_T GridEyeCommandParam;
extern uint8  inter_src; 


    
CYBLE_GATTC_HANDLE_VALUE_NTF_PARAM_T  GridEyePacket;
 

#endif

static CYBLE_GAP_BD_ADDR_T      GridEyeAddr;


/*Function Prototypes */ 
 void Parse_Command(uint8 command); 
 void Char_to_Pixel_FirstDigit(uint8 pixel); 
 void Char_to_Pixel_SecondDigit(uint8 pixel); 
 void HandleScanningState(); 
 void BLECallBack(uint32 event, void *eventParam); 
 void Populate_Structures(); 
 void Update_command(); 
/* [] END OF FILE */
