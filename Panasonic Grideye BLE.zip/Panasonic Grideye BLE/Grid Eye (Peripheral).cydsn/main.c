/* 

The following is a simple demo program to demonstrate the capabilites of the Panasonic Grid Eye sensor and Cypress PROC ble module. 

Written by M. Bon for Digikey Electronics
October 2016

*/

/*Defines & Includes  */ 
#include "main.h"

/*
*
*  Callback function to handle BLE events
* 
*/ 
CY_ISR_PROTO(Timer_Interrupt); 

void BLECallBack(uint32 event, void *eventParam)
{
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
    
   	switch (event)
    {
        case CYBLE_EVT_STACK_ON:
		{	/* start advertising */
	        CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
            break; 
        }
        
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
        {
           CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST); // restart adverstising
            break; 
        }
        
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
        { 
          CyBle_GappStopAdvertisement(); 
          LED_Write(1); 

           break; 
            
        } 
        
        case CYBLE_EVT_GATTS_XCNHG_MTU_REQ:
        {
            CYBLE_GATT_XCHG_MTU_PARAM_T        mtuExchgParam; 
            
            mtuExchgParam = *(CYBLE_GATT_XCHG_MTU_PARAM_T*)eventParam;
            CyBle_GattsExchangeMtuRsp(cyBle_connHandle, mtuExchgParam.mtu);  
            break;
        }
        
        case CYBLE_EVT_GATTS_WRITE_REQ:
	    case CYBLE_EVT_GATTS_WRITE_CMD_REQ:
        {
            wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;
            
            /*Handle Pixel Number*/ 
            
           if(wrReqParam->handleValPair.attrHandle == CYBLE_PIXEL_DATA_PIXEL_NUMBER_CHAR_HANDLE)
    	        {
                    pixel = wrReqParam->handleValPair.value.val[0];
                    Get_Pixel(pixel); 
                }
            
            
            /*Handle Commands*/ 
            if(wrReqParam->handleValPair.attrHandle == CYBLE_GRID_EYE_COMMANDS_GRID_EYE_COMMANDS_CHAR_HANDLE)
    	        {
                    command = wrReqParam->handleValPair.value.val[0]; 
                    
                    if (command == 0x0A) 
                        { 
                            CYBLE_GATT_HANDLE_VALUE_PAIR_T    ThermistorHandle;
                            Get_Thermistor();  
                            Thermistor_Total = (Thermistor_High << 8 ) + Thermistor_Low; 
                            ThermistorHandle.attrHandle = CYBLE_THERMISTOR_DATA_THERMISTOR_DATA_CHAR_HANDLE;
                            ThermistorHandle.value.val = &Thermistor_Total;
                            ThermistorHandle.value.len = 2;
                            CyBle_GattsWriteAttributeValue(&ThermistorHandle, 0, &cyBle_connHandle,CYBLE_GATT_DB_LOCALLY_INITIATED);
            
                           
                        }
                    else if (command == 0x0B)
                        {
               
                            CYBLE_GATT_HANDLE_VALUE_PAIR_T PixelHandle;  
                            PixelHandle.attrHandle= CYBLE_PIXEL_DATA_PIXEL_DATA_CHAR_HANDLE; 
                            pixel_total = ( pixel_value_HIGH << 8) + pixel_value_LOW;  
                            PixelHandle.value.val = &pixel_total; 
                            PixelHandle.value.len = 2;
                            CyBle_GattsWriteAttributeValue(&PixelHandle, 0, &cyBle_connHandle, CYBLE_GATT_DB_LOCALLY_INITIATED); 
                            
                        }
                    
                    else if (command == 0x0C) 
                        { 
                            Data_stream = True;
                            
                           
                        } 
                    
                    else if (command == 0x0D)
                        {
                            
                            Data_stream = False; 
                        }
                    
                    else 
                        {
                            //ignore 
                        } 
                        
                }
            else 
                    {
                        // fail  
                    }
            
            
            
            
            if (event == CYBLE_EVT_GATTS_WRITE_REQ)
			    {
	                CyBle_GattsWriteRsp(cyBle_connHandle);
			    }
            
            break; 
        }
        
    }
}

int main()
{
    /* Set pullups on I2C pins */
    I2C_scl_SetDriveMode(I2C_scl_DM_RES_UP); 
    I2C_sda_SetDriveMode(I2C_sda_DM_RES_UP);

    /* Start peripherals  */
    I2C_Start();  
    isr_Timer_StartEx(Timer_Interrupt); 
    Timer_Start(); 
    
       
    CyGlobalIntEnable;
    CyBle_Start(BLECallBack); 
    
    for(;;)
        {
                       	
          CyBle_ProcessEvents(); // Do BLE and interrupt stuff 
        
        }
}

CY_ISR(Timer_Interrupt)

{
    Get_Packet();   
    
    if ( Data_stream == True) //if the host commands the server to stream data, send grid eye data to the BLE notification. 
        {   
            if (Data_Update == False) //ensure BLE and sensor reading isn't taking place. 
                { 
                            Data_Update = True; 
                    
                             
                            CYBLE_GATT_HANDLE_VALUE_PAIR_T  Grid_Eye_ByteHandle; 
                            Grid_Eye_ByteHandle.attrHandle = CYBLE_GRID_EYE_DATA__GRID_EYE_DATA_CHAR_HANDLE;
                            Grid_Eye_ByteHandle.value.val = &temp; 
                            Grid_Eye_ByteHandle.value.len = 130; 
                            CyBle_GattsNotification(cyBle_connHandle, &Grid_Eye_ByteHandle); 
                            Data_Update = False; 
                }
            
        }
    
}

/* Gets high and low value from the pixel specifed by the user and returns it via BLE*/ 
void Get_Pixel(uint8 pixel) 
{
    
    uint16 pixel_number = 2*pixel-1; //convert pixel number to correct starting register. 
    
    if (pixel <= 64 && pixel > 0)// Check for valid register  
        {
          
             pixel_value_LOW  = temp[pixel_number-1]; 
             pixel_value_HIGH = temp[pixel_number]; 
                       
        }
    
    else 
        { 
           
        } 
    
}

/*Returns high and low thermistor value via BLE */
void Get_Thermistor()
{
    Thermistor_Low = temp[128]; 
    Thermistor_High = temp[129]; 
    
}



/*Returns Thermistor and all pixel values via BLE.*/
void Get_Packet()
{
    if ( Data_Update == False) // If no BLE transfer is happening, update the data 
        { 
          Data_Update = True; // Ensure data transfer doesn't get interrupted.
          Timer_ClearInterrupt(Timer_INTR_MASK_TC); 
          i = 0; 
          j = 0;  
           
        
          I2C_I2CMasterSendStart(104, 0); //write to Grid Eye
          I2C_I2CMasterWriteByte(0x0E); 
          I2C_I2CMasterSendStop(); 
          CyDelayUs(15); 
          
          I2C_I2CMasterSendStart(104, 1); //Read from Grid Eye 
          temp[128] = I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA);  
          CyDelayUs(300); 
          temp[129] = I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA);
          CyDelayUs(300); 
          I2C_I2CMasterSendStop(); 
          CyDelayUs(800);
          I2C_I2CMasterSendStart(104, 0); 
          I2C_I2CMasterWriteByte(128); 
          I2C_I2CMasterSendStop(); 
          CyDelayUs(15); 
        
        
                I2C_I2CMasterSendStart(104, 1); 
                for ( j = 0; j <128; j++) 
                {
                  temp[j] = I2C_I2CMasterReadByte(I2C_I2C_ACK_DATA); 
                  CyDelayUs(300);     
                }
                
                 I2C_I2CMasterSendStop();  
                
                
            
            Data_Update = False; 
        }
    else //If we somehow enter this interrupt during a BLE transfer, exit as quick as possible 
        {
            
        }   
    
    
    
} 



/* [] END OF FILE */
