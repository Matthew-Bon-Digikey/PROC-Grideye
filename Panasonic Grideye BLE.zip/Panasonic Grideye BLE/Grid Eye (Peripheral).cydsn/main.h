/* 
Written by M. Bon for Digikey Electronics
October 2016
*/
#include <project.h>
#include <timer.h>

#define True  (1)
#define False (0)
#define Grid_Eye_Commands_handle = 0x59u; 


/*Globals */ 
int i; 
int j; 
uint8 temp[130] = {0};  // Stores Pixel data 
uint8 pixel = 0;      // Pixel number 0 through 64
uint8 Thermistor_High = 0; 
uint8 Thermistor_Low  = 0;
uint16 Thermistor_Total = 0;  
int Data_Update = 0;  //Keeps the pixel data from being sent via BLE when it's being updated and vice-versa 
uint8 pixel_value_LOW = 0; 
uint8 pixel_value_HIGH = 0; 
uint8 pixel_bytes[2] = {0}; 
uint16 pixel_total = 0; 
uint8 command = 0; //Stores command recieved from Client 
uint8 Notification_Byte[1]; //Sends each data packet from temp array to notification. 
uint8 Data_stream = False; 



/*Function Prototypes */ 
void    Get_Pixel(uint8 pixel); //returns high and low values for one pixel 
void    Get_Thermistor(); //returns high and low thermistor values 
void    Get_Packet();     //returns high and low values for thermistor and all the pixels. 
/* [] END OF FILE */
